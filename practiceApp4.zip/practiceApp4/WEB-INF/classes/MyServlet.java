import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MyServlet extends HttpServlet
{


	static
	{
	System.out.println("Servlet Loading");
	}

	public MyServlet()
	{
	System.out.println("Servlet Instantiation");
	}
	
	public void init()
	{
	System.out.println("Servlet Initialization");
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
	System.out.println("Request Processing");
	}

	public void destroy()
	{
	System.out.println("Servlet Deinstantiation");
	}

}