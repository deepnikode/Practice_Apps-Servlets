import javax.servlet.*;
import java.io.*;


public class MyServlet extends GenericServlet
{

public void service(ServletRequest request,ServletResponse response)throws ServletException,IOException
{
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();

	ServletConfig config=getServletConfig();

	ServletContext context=getServletContext();

	String lname=context.getServletContextName();

	String driverClass=config.getInitParameter("driverClass");
	String url=config.getInitParameter("url");
	
	String contA =context.getInitParameter("A");
	String contB =context.getInitParameter("B");

	out.println("<html>");
	out.println("<body>");
	out.println("<h2>");
	out.println("<b>");
	out.println("Driver CLass : "+driverClass+ "<br>");
	out.println("URl : "+url +"<br>");
	out.println("Logical-Name"+lname+"<br>");
	out.println("Context-A"+contA+"<br>");
	out.println("Context-B"+contB+"<br>");
	out.println("</b> </font> </h2> </body> </html>");

}

}
