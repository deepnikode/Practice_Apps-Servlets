import java.io.*;
import javax.servlet.*;


public class MyServlet implements Servlet
{

public void init(ServletConfig conf) throws ServletException
{}

public void service(ServletRequest request,ServletResponse response)throws ServletException,IOException
{
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();

	out.println("<html>");
	out.println("<body>");
	out.println("<h5>");
	out.println("<font color='red'>");
	out.println("<b>");
	out.println("JAI HANUMAN");
	out.println("</b> </font> </h5> </body> </html>");
	
}

public ServletConfig getServletConfig()
{return null;} 

public String getServletInfo()
{return "";}

public void destroy()
{}

}