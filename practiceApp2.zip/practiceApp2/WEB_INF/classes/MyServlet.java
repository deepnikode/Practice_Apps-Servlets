import java.io.*;
import javax.servlet.*;
import java.util.*;

public class MyServlet extends GenericServlet
{

public void service(ServletRequest request, ServletResponse response)throws ServletException,IOException
{

response.setContentType("text/html");
PrintWriter out=response.getWriter();

ServletConfig config=getServletConfig();

String lname=config.getServletName();
String driverClass=config.getInitParameter("driverClass");
String url=config.getInitParameter("url");
String username=config.getInitParameter("username");
String password=config.getInitParameter("password");

Enumeration <String>e=config.getInitParameterNames();

String paramNames= "";

while(e.hasMoreElements())
{
paramNames=paramNames +e.nextElement()+ "<br>";
}

        out.println("<html>");
        out.println("<body>");
        out.println("<h3>");
        out.println("LOGICAL NAME: " + lname + "<br>");
        out.println("DRIVER CLASS: " + driverClass + "<br>");
        out.println("DRIVER URL: " + url + "<br>");
        out.println("USER-NAME: " + username + "<br>");
        out.println("PASSWORD: " + password + "<br>");
        out.println("INITIALIZATION PARAMETERS:<br>");
        out.println(paramNames);
        out.println("</h3> </body> </html>");
}

}