import java.io.*;
import javax.servlet.*;


public class WelcomeServlet extends GenericServlet 
{
	public void service(ServletRequest request,ServletResponse response) throws 	ServletException,IOException
	{
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();

	out.println("<html>");
	out.println("<body>");
	out.println("<h4>");
	out.println("<font color='red'>");
	out.println("<b>");
	out.println("Jay Shree Ram");
	out.println("</b> </font> </h4> </body> </html>");
	
	}
}