import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class MyServlet extends HttpServlet
{

public void service(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
	res.setContentType("text/html");
	PrintWriter out=res.getWriter();

	int i =Integer.parseInt(req.getParameter("num1"));
	int j =Integer.parseInt(req.getParameter("num2"));

	int k=i+j;
	
	out.println("Result is"+k);
	}
}